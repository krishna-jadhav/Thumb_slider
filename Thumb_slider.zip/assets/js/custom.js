   $('#special-deal').owlCarousel({
       loop: false,
       margin: 5,
       nav: true,
       responsive: {
           0: {
               items: 1
           },
           600: {
               items: 2
           },
           1000: {
               items: 3
           }
       }
   })


   // number
    $(document).ready(function() {
      $('.minus').click(function () {
        var $input = $(this).parent().find('input');
        var count = parseInt($input.val()) - 1;
        count = count < 1 ? 1 : count;
        $input.val(count);
        $input.change();
        return false;
      });
      $('.plus').click(function () {
        var $input = $(this).parent().find('input');
        $input.val(parseInt($input.val()) + 1);
        $input.change();
        return false;
      });
    });

    // back to top button\

        var btn = $('#button');

$(window).scroll(function() {
  if ($(window).scrollTop() > 300) {
    btn.addClass('show');
  } else {
    btn.removeClass('show');
  }
});

btn.on('click', function(e) {
  e.preventDefault();
  $('html, body').animate({scrollTop:0}, '300');
});

//toggle
$("#nav-icon").click(function () {
  $(this).toggleClass("open");
  $("body").toggleClass("menu-open");
});

$(".overlay-close, .bottom-header ul li a").click(function () {
  $("#nav-icon").removeClass("open");
  $("body").removeClass("menu-open");
});
$('.clicktoopen').click(function(){
    $(this).next().slideToggle();
});

// wow animation
wow = new WOW({
  boxClass: "wow", // default
  animateClass: "animated", // default
  offset: 0, // default
  mobile: false, // default
  live: true, // default
});
wow.init();

// Loader
$(window).on('load',function () {
  $(".loader").fadeOut(1000);
});

//=============================== Swiper slider==========================
 
$(document).ready(function(){
      
        $('.slider-for').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            asNavFor: '.slider-nav'
            });
            $('.slider-nav').slick({
            slidesToShow: 4,
            slidesToScroll: 1,
            asNavFor: '.slider-for',
            dots: true,
            vertical: true,
            centerMode: true,
            focusOnSelect: true,
            verticalSwiping: true,
            });
                
    });
  
//=============================== Swiper slider END ==========================